import React from 'react';
import { MicrosoftLogo, MinecraftCertBookIcon } from '../MinecraftIcons';

const Certifications = () => {
  const certs = [
    {
      title: 'Microsoft Azure Fundamentals (AZ-900)',
      issuer: 'Microsoft',
      badge: <MicrosoftLogo size={28} />,
      tag: 'Cloud Certified',
      link: 'https://learn.microsoft.com/en-us/certifications/azure-fundamentals/',
    },
  ];

  const achievements = [
    {
      title: 'University Technical & Academic Activities',
      desc: 'Active participant in GLA University technical events, coding workshops, and academic seminars.',
      icon: '🏆',
    },
    {
      title: 'AI/ML & Software Development',
      desc: 'Developed multiple practical projects applying machine learning, data engineering, and modern development stacks.',
      icon: '💡',
    },
    {
      title: 'Career & Internship Readiness',
      desc: 'Consistently honing core DSA, Java, and Python fundamentals for software engineering and AI internship roles.',
      icon: '🚀',
    },
  ];

  const activities = [
    {
      title: 'Dance Club — GLA University',
      desc: 'Active member participating in university cultural events, stage performances, and creative choreography.',
      icon: '💃',
    },
    {
      title: 'Cultural & Creative Events',
      desc: 'Engaging in diverse university-level co-curricular and creative activities.',
      icon: '✨',
    },
  ];

  return (
    <div className="page-content-wrapper">
      <div className="page-glass-panel">
        <div className="panel-header">
          <div className="panel-icon-badge" style={{ borderColor: 'rgba(255, 210, 122, 0.3)', background: 'rgba(255, 210, 122, 0.1)' }}>
            <MinecraftCertBookIcon size={30} />
          </div>
          <div>
            <h1 className="panel-title">Certifications &amp; Honors</h1>
            <p className="panel-subtitle" style={{ color: 'var(--gold)' }}>Credentials, Achievements &amp; Activities</p>
          </div>
        </div>

        <p className="panel-body-text">
          Industry-recognized certifications, university milestones, and co-curricular leadership.
        </p>

        {/* Official Certifications Card with Real Microsoft Logo */}
        <div style={{ marginBottom: '20px' }}>
          <h3 style={{ fontSize: '13px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--cyan)', fontWeight: 700, marginBottom: '10px' }}>
            Official Certifications
          </h3>
          <div style={{ background: 'rgba(255, 255, 255, 0.05)', borderRadius: '16px', border: '1px solid rgba(255, 255, 255, 0.14)', overflow: 'hidden' }}>
            {certs.map((c) => (
              <div
                key={c.title}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '16px 20px',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,0.15)' }}>
                    {c.badge}
                  </div>
                  <div>
                    <div style={{ fontSize: '15px', fontWeight: 700, color: '#ffffff' }}>{c.title}</div>
                    <div style={{ fontSize: '13px', color: 'var(--muted)', marginTop: '2px' }}>{c.issuer}</div>
                  </div>
                </div>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--green)', padding: '5px 12px', borderRadius: '20px', background: 'rgba(126, 217, 87, 0.15)', border: '1px solid rgba(126, 217, 87, 0.35)' }}>
                  {c.tag}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements Section */}
        <div style={{ marginBottom: '20px' }}>
          <h3 style={{ fontSize: '13px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--gold)', fontWeight: 700, marginBottom: '10px' }}>
            Achievements
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {achievements.map((a) => (
              <div
                key={a.title}
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  padding: '12px 16px',
                  borderRadius: '12px',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '12px',
                }}
              >
                <span style={{ fontSize: '18px' }}>{a.icon}</span>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#ffffff' }}>{a.title}</div>
                  <div style={{ fontSize: '12.5px', color: '#c4cec4', marginTop: '2px', lineHeight: '1.5' }}>{a.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Co-Curricular & Activities */}
        <div>
          <h3 style={{ fontSize: '13px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--purple)', fontWeight: 700, marginBottom: '10px' }}>
            Activities &amp; Leadership
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {activities.map((act) => (
              <div
                key={act.title}
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  padding: '12px 16px',
                  borderRadius: '12px',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '12px',
                }}
              >
                <span style={{ fontSize: '18px' }}>{act.icon}</span>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#ffffff' }}>{act.title}</div>
                  <div style={{ fontSize: '12.5px', color: '#c4cec4', marginTop: '2px', lineHeight: '1.5' }}>{act.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Certifications;
