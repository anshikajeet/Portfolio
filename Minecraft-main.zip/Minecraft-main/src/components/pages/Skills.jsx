import React from 'react';
import { MinecraftDiamondSwordIcon } from '../MinecraftIcons';

const Skills = () => {
  const skillCategories = [
    {
      category: 'Languages & Core',
      chips: ['Python', 'Java', 'SQL'],
    },
    {
      category: 'Programming & Concepts',
      chips: ['Data Structures & Algorithms', 'Object-Oriented Programming (OOP)'],
    },
    {
      category: 'AI & Machine Learning',
      chips: ['Machine Learning', 'NumPy', 'Pandas', 'Data Visualization', 'Data Engineering'],
    },
    {
      category: 'Database Systems',
      chips: ['MySQL', 'DBMS'],
    },
    {
      category: 'Cloud & Developer Tools',
      chips: ['Microsoft Azure', 'GitHub', 'VS Code'],
    },
  ];

  return (
    <div className="page-content-wrapper">
      <div className="page-glass-panel">
        <div className="panel-header">
          <div className="panel-icon-badge" style={{ borderColor: 'rgba(94, 234, 212, 0.3)', background: 'rgba(94, 234, 212, 0.1)' }}>
            <MinecraftDiamondSwordIcon size={30} />
          </div>
          <div>
            <h1 className="panel-title">Technical Skills</h1>
            <p className="panel-subtitle" style={{ color: 'var(--cyan)' }}>Engineering &amp; AI Toolkit</p>
          </div>
        </div>

        <p className="panel-body-text">
          My core competencies across programming languages, AI/ML libraries, database management, and cloud tools.
        </p>

        <div className="skills-grid">
          {skillCategories.map((group) => (
            <div key={group.category} className="skill-group">
              <div className="skill-category-title">{group.category}</div>
              <div className="chips-wrap">
                {group.chips.map((skill) => (
                  <span key={skill} className="skill-chip">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;
