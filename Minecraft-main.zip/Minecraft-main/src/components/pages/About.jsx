import React from 'react';
import { MinecraftOakBlockIcon } from '../MinecraftIcons';

const About = () => {
  return (
    <>
      {/* Character Speech Bubble over waving Anshika on About page */}
      <div className="character-speech-bubble" style={{ left: '44%', bottom: '58%' }}>
        <div className="speech-content">
          <span style={{ fontSize: '18px' }}>🌸</span>
          <div>
            <span className="speech-name">Hey, I am Anshika!</span>
            <span className="speech-wave">👋</span>
          </div>
        </div>
        <div className="speech-tail" />
      </div>

      {/* Main Glassmorphic Info Panel on the Right */}
      <div className="page-content-wrapper">
        <div className="page-glass-panel">
          <div className="panel-header">
            <div className="panel-icon-badge">
              <MinecraftOakBlockIcon size={30} />
            </div>
            <div>
              <h1 className="panel-title">About Me</h1>
              <p className="panel-subtitle">Anshika Jeet Singh • B.Tech CSE (AI &amp; ML)</p>
            </div>
          </div>

          <p className="panel-body-text">
            I am a <strong>B.Tech CSE (AI &amp; ML) student at GLA University</strong>, passionate about Artificial Intelligence, Machine Learning, and software development. I enjoy building practical projects, solving programming problems, and continuously improving my technical skills.
          </p>

          <p className="panel-body-text">
            I am currently focusing on <strong>Python, Java, Data Structures, Machine Learning</strong>, and modern development tools while exploring opportunities to apply my skills through real-world projects and internships.
          </p>

          {/* Quest Info Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', marginTop: '16px' }}>
            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '14px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontSize: '11px', color: 'var(--green)', fontWeight: 700, letterSpacing: '0.8px' }}>COLLEGE &amp; DEGREE</div>
              <div style={{ fontSize: '15px', fontWeight: 800, marginTop: '4px' }}>GLA University, Mathura</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '2px' }}>B.Tech CSE (AI &amp; ML)</div>
            </div>

            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '14px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontSize: '11px', color: 'var(--cyan)', fontWeight: 700, letterSpacing: '0.8px' }}>TIMELINE &amp; YEAR</div>
              <div style={{ fontSize: '15px', fontWeight: 800, marginTop: '4px' }}>2nd Year (2025 – 2029)</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '2px' }}>Expected Grad: 2029</div>
            </div>

            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '14px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontSize: '11px', color: 'var(--amber)', fontWeight: 700, letterSpacing: '0.8px' }}>LOCATION</div>
              <div style={{ fontSize: '15px', fontWeight: 800, marginTop: '4px' }}>Kanpur, UP, India 📍</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '2px' }}>Uttar Pradesh</div>
            </div>

            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '14px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontSize: '11px', color: 'var(--purple)', fontWeight: 700, letterSpacing: '0.8px' }}>CREATIVE ACTIVITIES</div>
              <div style={{ fontSize: '15px', fontWeight: 800, marginTop: '4px' }}>Dance Club 💃</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '2px' }}>GLA Cultural Events</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default About;
