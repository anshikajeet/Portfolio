import React from 'react';

const PageWrapper = ({ children, title, subtitle }) => {
  return (
    <div style={{
      width: '100%',
      height: '100%',
      padding: '40px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'flex-start',
    }}>
      <div className="glass-panel animate-float" style={{
        padding: '40px',
        maxWidth: '700px',
        animationDelay: '0.2s',
      }}>
        {title && <h1 style={{ 
          fontSize: '3rem', 
          marginBottom: '10px',
          background: 'linear-gradient(90deg, #fff, var(--accent-cyan))',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          fontWeight: 700
        }}>{title}</h1>}
        
        {subtitle && <h3 style={{ 
          color: 'var(--accent-gold)', 
          fontSize: '1.2rem', 
          marginBottom: '20px',
          fontWeight: 400
        }}>{subtitle}</h3>}
        
        <div style={{
          lineHeight: '1.6',
          fontSize: '1.1rem',
          color: 'var(--text-primary)'
        }}>
          {children}
        </div>
      </div>
    </div>
  );
};

export default PageWrapper;
