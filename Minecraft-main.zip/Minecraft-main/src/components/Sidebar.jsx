import React from 'react';
import { soundFX } from '../utils/audio';
import {
  MinecraftHomeIcon,
  MinecraftOakBlockIcon,
  MinecraftDiamondSwordIcon,
  MinecraftGrassBlockIcon,
  MinecraftCertBookIcon,
  MinecraftLanternIcon,
} from './MinecraftIcons';

const Sidebar = ({ activePage, setActivePage }) => {
  const navItems = [
    { id: 'Home', name: 'Home', icon: <MinecraftHomeIcon />, subtitle: 'Welcome to my world' },
    { id: 'About', name: 'About', icon: <MinecraftOakBlockIcon />, subtitle: 'Know more about me' },
    { id: 'Skills', name: 'Skills', icon: <MinecraftDiamondSwordIcon />, subtitle: 'Technical expertise' },
    { id: 'Projects', name: 'Projects', icon: <MinecraftGrassBlockIcon />, subtitle: "Things I've built" },
    { id: 'Certifications', name: 'Certifications', icon: <MinecraftCertBookIcon />, subtitle: 'Achievements & awards' },
    { id: 'Contact', name: 'Contact', icon: <MinecraftLanternIcon />, subtitle: "Let's connect" },
  ];

  const handleNavClick = (id) => {
    soundFX.playClick();
    setActivePage(id);
  };

  const handleSocialClick = (url) => {
    soundFX.playPop();
    window.open(url, '_blank');
  };

  return (
    <aside className="glass-sidebar">
      {/* Profile Header with User's Avatar */}
      <div className="profile-header">
        <div className="profile-avatar-box">
          <img
            src="/image.png"
            alt="Anshika Jeet Singh"
            className="avatar-img"
            style={{ borderRadius: '50%', objectFit: 'cover' }}
          />
        </div>

        <div className="profile-info">
          <h2 className="profile-name" style={{ fontSize: '17px' }}>Anshika Jeet Singh</h2>
          <div className="profile-role">
            <span>B.Tech CSE (AI &amp; ML)</span>
          </div>
        </div>
      </div>

      {/* Navigation List with authentic Minecraft item icons */}
      <nav className="nav-list">
        {navItems.map((item) => {
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              className={`nav-btn ${isActive ? 'active' : ''}`}
              onClick={() => handleNavClick(item.id)}
            >
              <div className="nav-icon-container">
                {item.icon}
              </div>
              <div className="nav-text-col">
                <span className="nav-title">{item.name}</span>
                <span className="nav-subtitle">{item.subtitle}</span>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Footer Social Buttons */}
      <div className="sidebar-footer">
        <div className="social-grid">
          {/* GitHub */}
          <button
            className="social-btn"
            title="GitHub: anshikajeet"
            onClick={() => handleSocialClick('https://github.com/anshikajeet')}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
            </svg>
          </button>

          {/* LinkedIn */}
          <button
            className="social-btn"
            title="LinkedIn Profile"
            onClick={() => handleSocialClick('https://www.linkedin.com/in/anshikajeet-singh-14s?utm_source=share_via&utm_content=profile&utm_medium=member_ios')}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
            </svg>
          </button>

          {/* Mail */}
          <button
            className="social-btn"
            title="Email: anshikajeetsingh50@gmail.com"
            onClick={() => handleSocialClick('mailto:anshikajeetsingh50@gmail.com')}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M0 3v18h24v-18h-24zm21.518 2l-9.518 7.713-9.518-7.713h19.036zm-19.518 14v-11.817l9.518 7.713 9.518-7.713v11.817h-19.036z" />
            </svg>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
