import React, { useMemo } from 'react';

const Particles = ({ activePage }) => {
  // Generate random particles for ambient lighting
  const fireflies = useMemo(() => {
    return Array.from({ length: 14 }).map((_, i) => ({
      id: `f-${i}`,
      left: `${5 + Math.random() * 85}%`,
      top: `${35 + Math.random() * 55}%`,
      size: `${3 + Math.random() * 4}px`,
      duration: `${4 + Math.random() * 4}s`,
      delay: `${Math.random() * 4}s`,
      color: activePage === 'Skills' ? '#5eead4' : activePage === 'Projects' || activePage === 'Certifications' ? '#c084fc' : '#ffd27a',
      glow: activePage === 'Skills' ? 'rgba(94, 234, 212, 0.9)' : activePage === 'Projects' || activePage === 'Certifications' ? 'rgba(192, 132, 252, 0.9)' : 'rgba(255, 210, 122, 0.9)',
    }));
  }, [activePage]);

  // Zzz sleepy particles for cozy cottage / contact scene
  const zzzList = [
    { id: 1, left: '68%', top: '35%', size: '18px', delay: '0s' },
    { id: 2, left: '71%', top: '28%', size: '14px', delay: '1.2s' },
    { id: 3, left: '66%', top: '40%', size: '20px', delay: '2.5s' },
  ];

  return (
    <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 15, overflow: 'hidden' }}>
      {/* Drifting Fireflies & Sparks */}
      {fireflies.map((p) => (
        <div
          key={p.id}
          className="sparkle-particle"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            boxShadow: `0 0 10px 3px ${p.glow}`,
            animationDuration: p.duration,
            animationDelay: p.delay,
          }}
        />
      ))}

      {/* Floating Zzz on Contact page or Home page */}
      {(activePage === 'Contact' || activePage === 'Home') &&
        zzzList.map((z) => (
          <div
            key={z.id}
            className="zzz-particle"
            style={{
              left: z.left,
              top: z.top,
              fontSize: z.size,
              animationDelay: z.delay,
            }}
          >
            z
          </div>
        ))}
    </div>
  );
};

export default Particles;
