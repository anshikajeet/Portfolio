<div align="center">

# ⛏️ Minecraft Portfolio

### A cinematic developer portfolio reimagined as a Minecraft-inspired world.

<p>
  <b>Explore the world • Discover the story • See what I've built</b>
</p>

<br>

[![React](https://img.shields.io/badge/React-19-61DAFB?style=for-the-badge&logo=react&logoColor=white)](https://react.dev/)
[![Vite](https://img.shields.io/badge/Vite-8-646CFF?style=for-the-badge&logo=vite&logoColor=white)](https://vite.dev/)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES2026-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![CSS3](https://img.shields.io/badge/CSS3-Glassmorphism-1572B6?style=for-the-badge&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)

<br>

🌐 **Live Website:** https://minecraft-tau-two.vercel.app/

</div>

---

## 🎮 About The Project

**Minecraft Portfolio** is an interactive developer portfolio inspired by the visual language of Minecraft.

Instead of presenting a traditional portfolio with static cards and sections, the website turns the portfolio into a **cinematic game-like experience**.

Each portfolio section exists inside its own Minecraft-inspired environment.

> **The world is the interface.**

The goal was to combine:

- 🎮 Minecraft-inspired visual storytelling
- 🪟 Modern glassmorphism UI
- 🎥 Cinematic camera movement
- ✨ Atmospheric animations
- 🧱 Pixel-inspired design
- ⚡ Modern React architecture

---

## 🌎 Portfolio World

| Section | World |
|---|---|
| 🏠 **Home** | Cozy Minecraft cottage |
| 📖 **About** | Enchanted wooden library |
| ⚔️ **Skills** | Minecraft-inspired combat/skill environment |
| 🌌 **Projects** | End-dimension adventure |
| 📜 **Certifications** | Enchanted study room |
| 🏮 **Contact** | Cinematic night environment |

Each environment changes dynamically when the user navigates between sections.

---

## ✨ Features

### 🪟 Glassmorphism Navigation

A frosted-glass sidebar stays over the cinematic environment while keeping the interface minimal and readable.

### 🎥 Cinematic Mode

The portfolio includes a dedicated cinematic mode that hides the interface and allows the visitor to experience the environment by itself.

```text
🔭 Cinematic Scene
        ↓
Hide UI
        ↓
Explore the environment
        ↓
Mouse movement → Camera movement
