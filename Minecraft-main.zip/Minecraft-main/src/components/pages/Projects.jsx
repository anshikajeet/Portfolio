import React from 'react';
import { soundFX } from '../../utils/audio';
import { MinecraftGrassBlockIcon } from '../MinecraftIcons';

const Projects = () => {
  const projectsList = [
    {
      num: 'PROJECT 01',
      title: 'Travel SIM Sales Dashboard',
      desc: 'An analytical data engineering & visualization dashboard tracking international travel SIM sales metrics, regional distribution, churn rates, and revenue performance with interactive reporting.',
      tags: ['Python', 'SQL', 'Data Analytics', 'Data Visualization', 'Pandas', 'MySQL'],
      github: 'https://github.com/anshikajeet',
    },
    {
      num: 'PROJECT 02',
      title: 'AI Portfolio Generator',
      desc: 'An intelligent AI-powered generator that dynamically crafts personalized, aesthetic, and responsive developer portfolios tailored from user resumes and skillset inputs.',
      tags: ['AI & ML', 'Python', 'Web Development', 'NLP', 'Data Engineering'],
      github: 'https://github.com/anshikajeet',
    },
  ];

  return (
    <div className="page-content-wrapper">
      <div className="page-glass-panel">
        <div className="panel-header">
          <div className="panel-icon-badge" style={{ borderColor: 'rgba(192, 132, 252, 0.3)', background: 'rgba(192, 132, 252, 0.1)' }}>
            <MinecraftGrassBlockIcon size={30} />
          </div>
          <div>
            <h1 className="panel-title">Projects</h1>
            <p className="panel-subtitle" style={{ color: 'var(--purple)' }}>Practical Builds &amp; AI Applications</p>
          </div>
        </div>

        <p className="panel-body-text">
          Featured software engineering and artificial intelligence projects built with focus on data-driven insights and usability.
        </p>

        <div style={{ marginTop: '16px' }}>
          {projectsList.map((p) => (
            <div key={p.title} className="project-card">
              <div className="project-tag">{p.num}</div>
              <h3 className="project-heading">{p.title}</h3>
              <p className="project-desc">{p.desc}</p>
              
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '14px' }}>
                {p.tags.map((t) => (
                  <span
                    key={t}
                    style={{
                      fontSize: '11.5px',
                      padding: '4px 10px',
                      borderRadius: '8px',
                      background: 'rgba(255, 255, 255, 0.06)',
                      color: '#dbe4db',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      fontWeight: 500,
                    }}
                  >
                    {t}
                  </span>
                ))}
              </div>

              <a
                href={p.github}
                target="_blank"
                rel="noreferrer"
                className="project-link-btn"
                onClick={() => soundFX.playPop()}
              >
                <span>View on GitHub (anshikajeet)</span>
                <span>↗</span>
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Projects;
