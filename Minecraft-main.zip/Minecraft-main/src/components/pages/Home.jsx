import React from 'react';
import { soundFX } from '../../utils/audio';

const Home = ({ setActivePage }) => {
  return (
    <>
      {/* Floating Top Right Quote Card (matches what i want.png) */}
      <div className="floating-glass-card top-right-quote">
        <span className="quote-mark">“</span>
        <span>Builder &amp; developer crafting cozy corners of the internet, one block at a time. 🌿</span>
      </div>

      {/* Floating Bottom Right Call to Action Badge (matches what i want.png) */}
      <div
        className="floating-glass-card bottom-right-cta"
        onClick={() => {
          soundFX.playPop();
          setActivePage('Contact');
        }}
      >
        <span style={{ fontSize: '20px' }}>🌱</span>
        <span>
          Let's build something <span className="cta-highlight">amazing together!</span>
        </span>
      </div>
    </>
  );
};

export default Home;
