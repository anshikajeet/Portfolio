import React from 'react';

// Official Microsoft 4-square colored logo
export const MicrosoftLogo = ({ size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <rect x="1" y="1" width="10.5" height="10.5" fill="#F25022" rx="1" />
    <rect x="12.5" y="1" width="10.5" height="10.5" fill="#7FBA00" rx="1" />
    <rect x="1" y="12.5" width="10.5" height="10.5" fill="#00A4EF" rx="1" />
    <rect x="12.5" y="12.5" width="10.5" height="10.5" fill="#FFB900" rx="1" />
  </svg>
);

// Minecraft Pixel House (Home)
export const MinecraftHomeIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Roof */}
    <path d="M16 2 L4 14 H28 Z" fill="#b87333" stroke="#8b4513" strokeWidth="1" />
    <path d="M16 4 L6 14 H26 Z" fill="#d2915c" />
    <path d="M16 4 L16 14" stroke="#9e5c2b" strokeWidth="1" />
    {/* Chimney */}
    <rect x="20" y="4" width="4" height="6" fill="#696969" stroke="#333" strokeWidth="0.5" />
    {/* Walls */}
    <rect x="6" y="14" width="20" height="15" fill="#f5f5dc" stroke="#5c4033" strokeWidth="1" />
    <rect x="6" y="27" width="20" height="2" fill="#808080" />
    {/* Door */}
    <rect x="13" y="19" width="6" height="10" fill="#5c3a21" />
    <rect x="14" y="20" width="4" height="9" fill="#8b5a2b" />
    <circle cx="17.5" cy="24.5" r="0.8" fill="#ffd700" />
    {/* Windows */}
    <rect x="8" y="17" width="3" height="4" fill="#87ceeb" stroke="#5c4033" strokeWidth="0.5" />
    <rect x="21" y="17" width="3" height="4" fill="#87ceeb" stroke="#5c4033" strokeWidth="0.5" />
  </svg>
);

// Minecraft Oak Wood / Plank Block (About)
export const MinecraftOakBlockIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Top Face (isometric) */}
    <polygon points="16,3 29,10 16,17 3,10" fill="#c49a62" stroke="#6b4c2b" strokeWidth="0.8" />
    <polygon points="16,5 26,10.5 16,15.5 6,10.5" fill="#d8af75" />
    <line x1="10" y1="7.5" x2="22" y2="13.5" stroke="#a07542" strokeWidth="0.8" />
    {/* Left Face */}
    <polygon points="3,10 16,17 16,29 3,22" fill="#9e7240" stroke="#6b4c2b" strokeWidth="0.8" />
    <line x1="3" y1="14" x2="16" y2="21" stroke="#7a552b" strokeWidth="0.8" />
    <line x1="3" y1="18" x2="16" y2="25" stroke="#7a552b" strokeWidth="0.8" />
    {/* Right Face */}
    <polygon points="16,17 29,10 29,22 16,29" fill="#7d582e" stroke="#52381b" strokeWidth="0.8" />
    <line x1="16" y1="21" x2="29" y2="14" stroke="#5a3d1c" strokeWidth="0.8" />
    <line x1="16" y1="25" x2="29" y2="18" stroke="#5a3d1c" strokeWidth="0.8" />
  </svg>
);

// Minecraft Diamond Sword (Skills)
export const MinecraftDiamondSwordIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Blade */}
    <polygon points="26,3 29,6 14,21 11,18" fill="#5eead4" />
    <polygon points="27,4 28,5 15,18 14,17" fill="#ffffff" />
    <polygon points="26,3 29,6 27,8 24,5" fill="#a7f3d0" />
    <path d="M26,3 L29,6 L14,21 L11,18 Z" stroke="#0f766e" strokeWidth="1" />
    {/* Guard */}
    <rect x="8" y="17" width="5" height="5" fill="#0d9488" stroke="#134e4a" strokeWidth="0.8" />
    <rect x="14" y="17" width="4" height="4" fill="#0d9488" stroke="#134e4a" strokeWidth="0.8" />
    <rect x="10" y="21" width="4" height="4" fill="#0d9488" stroke="#134e4a" strokeWidth="0.8" />
    {/* Handle / Hilt */}
    <polygon points="9,21 12,24 6,30 3,27" fill="#854d0e" stroke="#451a03" strokeWidth="1" />
    <circle cx="4.5" cy="28.5" r="1.5" fill="#0d9488" />
  </svg>
);

// Minecraft Grass Block (Projects)
export const MinecraftGrassBlockIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Top Green Face */}
    <polygon points="16,3 29,10 16,17 3,10" fill="#5cb85c" stroke="#336633" strokeWidth="0.8" />
    <polygon points="16,5 26,10.5 16,15.5 6,10.5" fill="#7cd67c" />
    {/* Left Face (Dirt + Grass overhang) */}
    <polygon points="3,10 16,17 16,29 3,22" fill="#865439" stroke="#4a2e1b" strokeWidth="0.8" />
    {/* Left Grass Hang */}
    <polygon points="3,10 16,17 16,21 13,20 10,22 7,19 3,21" fill="#4d994d" />
    {/* Right Face (Dirt + Grass overhang) */}
    <polygon points="16,17 29,10 29,22 16,29" fill="#693e26" stroke="#3a1e10" strokeWidth="0.8" />
    {/* Right Grass Hang */}
    <polygon points="16,17 29,10 29,14 26,16 23,13 19,15 16,14" fill="#3d7a3d" />
    {/* Dirt speckles */}
    <rect x="8" y="23" width="2" height="2" fill="#54311c" />
    <rect x="12" y="25" width="2.5" height="2" fill="#a06b4b" />
    <rect x="22" y="20" width="2" height="2" fill="#4a2a16" />
    <rect x="19" y="24" width="2.5" height="2" fill="#8a5636" />
  </svg>
);

// Minecraft Enchanted Book / Certificate (Certifications)
export const MinecraftCertBookIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Book Cover (Red/Brown Leather) */}
    <polygon points="16,6 28,10 28,26 16,22" fill="#8b2500" stroke="#4a1500" strokeWidth="0.8" />
    <polygon points="16,6 4,10 4,26 16,22" fill="#a03000" stroke="#4a1500" strokeWidth="0.8" />
    {/* Pages (Parchment) */}
    <polygon points="16,8 26,11.5 26,24 16,20.5" fill="#fdf5e6" />
    <polygon points="16,8 6,11.5 6,24 16,20.5" fill="#faebd7" />
    <line x1="16" y1="8" x2="16" y2="21" stroke="#8b4513" strokeWidth="1" />
    {/* Gold Corner Clasps */}
    <rect x="24" y="10" width="3" height="3" fill="#ffd700" />
    <rect x="5" y="10" width="3" height="3" fill="#ffd700" />
    <rect x="24" y="22" width="3" height="3" fill="#ffd700" />
    <rect x="5" y="22" width="3" height="3" fill="#ffd700" />
    {/* Enchanted Purple Glow Ribbon */}
    <line x1="12" y1="12" x2="20" y2="18" stroke="#c084fc" strokeWidth="1.5" strokeDasharray="2 1" />
    <polygon points="16,14 18,17 14,17" fill="#e879f9" />
  </svg>
);

// Minecraft Glowing Lantern (Contact)
export const MinecraftLanternIcon = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className="pixelate">
    {/* Top Ring / Handle */}
    <circle cx="16" cy="5" r="2.5" stroke="#4a4a4a" strokeWidth="1.5" fill="none" />
    {/* Lantern Top Cap */}
    <rect x="12" y="7" width="8" height="2" fill="#3a3a3a" />
    <polygon points="9,9 23,9 21,12 11,12" fill="#525252" stroke="#262626" strokeWidth="0.5" />
    {/* Glass Body with Glowing Fire */}
    <rect x="10" y="12" width="12" height="12" fill="#ffa500" fillOpacity="0.8" stroke="#333333" strokeWidth="1" />
    {/* Inner White-Hot Flame */}
    <rect x="13" y="14" width="6" height="8" fill="#ffff99" />
    <rect x="14" y="15" width="4" height="5" fill="#ffffff" />
    {/* Metal Frame Corner Bars */}
    <line x1="10" y1="12" x2="10" y2="24" stroke="#262626" strokeWidth="1.5" />
    <line x1="22" y1="12" x2="22" y2="24" stroke="#262626" strokeWidth="1.5" />
    <line x1="10" y1="18" x2="22" y2="18" stroke="#262626" strokeWidth="0.8" />
    {/* Lantern Bottom Base */}
    <rect x="9" y="24" width="14" height="3" fill="#3a3a3a" stroke="#1f1f1f" strokeWidth="0.5" />
  </svg>
);
