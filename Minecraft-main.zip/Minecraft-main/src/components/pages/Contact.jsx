import React, { useState } from 'react';
import { soundFX } from '../../utils/audio';
import { MinecraftLanternIcon } from '../MinecraftIcons';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    soundFX.playPop();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 4000);
  };

  return (
    <div className="page-content-wrapper">
      <div className="page-glass-panel">
        <div className="panel-header">
          <div className="panel-icon-badge" style={{ borderColor: 'rgba(255, 170, 80, 0.3)', background: 'rgba(255, 170, 80, 0.1)' }}>
            <MinecraftLanternIcon size={30} />
          </div>
          <div>
            <h1 className="panel-title">Let's Connect</h1>
            <p className="panel-subtitle" style={{ color: 'var(--amber)' }}>Get in Touch • Anshika Jeet Singh</p>
          </div>
        </div>

        <p className="panel-body-text">
          Have an internship opportunity, project collaboration, or want to discuss AI/ML? My inbox is always open.
        </p>

        {/* Quick Contact Links with clean icons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
          {/* Email */}
          <a
            href="mailto:anshikajeetsingh50@gmail.com"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '13px 16px',
              borderRadius: '14px',
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              color: '#ffffff',
              fontSize: '14px',
              fontWeight: 500,
              transition: 'all 0.2s ease',
            }}
            onClick={() => soundFX.playClick()}
          >
            <span style={{ fontSize: '18px' }}>✉️</span>
            <span style={{ wordBreak: 'break-all' }}>anshikajeetsingh50@gmail.com</span>
          </a>

          {/* LinkedIn */}
          <a
            href="https://www.linkedin.com/in/anshikajeet-singh-14s?utm_source=share_via&utm_content=profile&utm_medium=member_ios"
            target="_blank"
            rel="noreferrer"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '13px 16px',
              borderRadius: '14px',
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              color: '#ffffff',
              fontSize: '14px',
              fontWeight: 500,
              transition: 'all 0.2s ease',
            }}
            onClick={() => soundFX.playClick()}
          >
            <span style={{ fontSize: '18px' }}>💼</span>
            <span>linkedin.com/in/anshikajeet-singh-14s</span>
          </a>

          {/* GitHub */}
          <a
            href="https://github.com/anshikajeet"
            target="_blank"
            rel="noreferrer"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '13px 16px',
              borderRadius: '14px',
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              color: '#ffffff',
              fontSize: '14px',
              fontWeight: 500,
              transition: 'all 0.2s ease',
            }}
            onClick={() => soundFX.playClick()}
          >
            <span style={{ fontSize: '18px' }}>🐙</span>
            <span>github.com/anshikajeet</span>
          </a>
        </div>

        {/* Interactive Dispatch Form */}
        <form onSubmit={handleSubmit} className="contact-form-group">
          <input
            type="text"
            className="glass-input"
            placeholder="Your Name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          <input
            type="email"
            className="glass-input"
            placeholder="Your Email Address"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
          <textarea
            rows="3"
            className="glass-input"
            placeholder="Your Message / Query..."
            required
            style={{ resize: 'vertical' }}
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          />

          <button type="submit" className="contact-action-btn">
            {submitted ? (
              <span>✨ Message Dispatched! Thank you.</span>
            ) : (
              <span>🚀 Send Message</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Contact;
