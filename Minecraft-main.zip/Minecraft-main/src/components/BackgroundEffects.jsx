import React, { useState, useEffect, useCallback, useMemo } from 'react';

const BackgroundEffects = ({ activePage, mousePos }) => {
  const [clickParticles, setClickParticles] = useState([]);

  // Spawn interactive particle bursts on user clicks (Hearts, XP Orbs, Magic Stars)
  const handleScreenClick = useCallback((e) => {
    // Ignore clicks on buttons/inputs to keep form inputs clean
    if (e.target.closest('button, a, input, textarea')) return;

    const shapes = ['xp', 'heart', 'star', 'sparkle', 'emerald'];
    const count = 7;
    const newItems = Array.from({ length: count }).map((_, i) => {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5);
      const velocity = 35 + Math.random() * 45;
      const shape = shapes[Math.floor(Math.random() * shapes.length)];
      return {
        id: `${Date.now()}-${Math.random()}`,
        x: e.clientX,
        y: e.clientY,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity - 20, // upward bias
        shape,
        size: 14 + Math.random() * 12,
        rotation: Math.random() * 360,
      };
    });

    setClickParticles((prev) => [...prev.slice(-25), ...newItems]);
  }, []);

  useEffect(() => {
    window.addEventListener('click', handleScreenClick);
    return () => window.removeEventListener('click', handleScreenClick);
  }, [handleScreenClick]);

  // Clean up click particles
  useEffect(() => {
    if (clickParticles.length === 0) return;
    const timer = setTimeout(() => {
      setClickParticles((prev) => prev.slice(5));
    }, 1400);
    return () => clearTimeout(timer);
  }, [clickParticles]);

  // 1. Biome Particles: Custom generated per active scene
  const biomeParticles = useMemo(() => {
    const isAbout = activePage === 'About';
    const isSkills = activePage === 'Skills';
    const isProjects = activePage === 'Projects';
    const isCerts = activePage === 'Certifications';
    const isContact = activePage === 'Contact';

    const count = isAbout ? 24 : 18;

    return Array.from({ length: count }).map((_, i) => ({
      id: `p-${activePage}-${i}`,
      left: `${Math.random() * 100}%`,
      top: isAbout ? `${-10 + Math.random() * 30}%` : `${20 + Math.random() * 75}%`,
      size: isAbout ? `${10 + Math.random() * 8}px` : `${4 + Math.random() * 6}px`,
      duration: isAbout ? `${6 + Math.random() * 5}s` : `${4 + Math.random() * 4}s`,
      delay: `${Math.random() * 5}s`,
      type: isAbout
        ? 'sakura'
        : isSkills
        ? 'rune'
        : isProjects
        ? 'purple-orb'
        : isCerts
        ? 'star'
        : isContact
        ? 'ember'
        : 'firefly',
      drift: `${(Math.random() - 0.5) * 60}px`,
    }));
  }, [activePage]);

  // Parallax subtle offset from mouse
  const parallaxX = (mousePos.x - 0.5) * 15;
  const parallaxY = (mousePos.y - 0.5) * 15;

  return (
    <div
      className="background-effects-container"
      style={{
        position: 'fixed',
        inset: 0,
        pointerEvents: 'none',
        zIndex: 12,
        overflow: 'hidden',
      }}
    >
      {/* EFFECT 1: Dynamic God Rays / Volumetric Sunbeams */}
      <div
        className={`god-rays-layer god-rays-${activePage.toLowerCase()}`}
        style={{
          transform: `translate3d(${parallaxX * 0.4}px, ${parallaxY * 0.4}px, 0)`,
        }}
      >
        <div className="god-ray-beam beam-1" />
        <div className="god-ray-beam beam-2" />
        <div className="god-ray-beam beam-3" />
        <div className="god-ray-beam beam-4" />
      </div>

      {/* EFFECT 2: Atmospheric Sun Flare / Biome Glow */}
      <div
        className={`sun-flare-layer flare-${activePage.toLowerCase()}`}
        style={{
          transform: `translate3d(${parallaxX * -0.6}px, ${parallaxY * -0.6}px, 0)`,
        }}
      />

      {/* EFFECT 3: Drifting Volumetric Mist / Fog Layers (Foreground & Midground) */}
      <div
        className="fog-layer fog-layer-mid"
        style={{
          transform: `translate3d(${parallaxX * 0.8}px, ${parallaxY * 0.2}px, 0)`,
        }}
      />
      <div
        className="fog-layer fog-layer-front"
        style={{
          transform: `translate3d(${parallaxX * 1.2}px, ${parallaxY * 0.3}px, 0)`,
        }}
      />

      {/* EFFECT 4: Biome Animated Ambient Particles (Sakura, Runes, Fireflies, Embers, Stars) */}
      <div
        className="biome-particles-wrapper"
        style={{
          transform: `translate3d(${parallaxX * 0.9}px, ${parallaxY * 0.9}px, 0)`,
        }}
      >
        {biomeParticles.map((p) => {
          if (p.type === 'sakura') {
            return (
              <div
                key={p.id}
                className="sakura-petal"
                style={{
                  left: p.left,
                  top: p.top,
                  width: p.size,
                  height: p.size,
                  animationDuration: p.duration,
                  animationDelay: p.delay,
                  '--drift': p.drift,
                }}
              />
            );
          }

          if (p.type === 'rune') {
            return (
              <div
                key={p.id}
                className="enchanted-rune"
                style={{
                  left: p.left,
                  top: p.top,
                  animationDuration: p.duration,
                  animationDelay: p.delay,
                }}
              >
                ✦
              </div>
            );
          }

          if (p.type === 'ember') {
            return (
              <div
                key={p.id}
                className="ember-spark"
                style={{
                  left: p.left,
                  top: p.top,
                  width: p.size,
                  height: p.size,
                  animationDuration: p.duration,
                  animationDelay: p.delay,
                }}
              />
            );
          }

          if (p.type === 'star') {
            return (
              <div
                key={p.id}
                className="star-sparkle"
                style={{
                  left: p.left,
                  top: p.top,
                  animationDuration: p.duration,
                  animationDelay: p.delay,
                }}
              >
                ★
              </div>
            );
          }

          // Default glowing firefly / magical orb
          return (
            <div
              key={p.id}
              className={`glow-firefly ${p.type}`}
              style={{
                left: p.left,
                top: p.top,
                width: p.size,
                height: p.size,
                animationDuration: p.duration,
                animationDelay: p.delay,
              }}
            />
          );
        })}
      </div>

      {/* EFFECT 5: Cozy Sleeping Zzz (Contact & Home scenes) */}
      {(activePage === 'Contact' || activePage === 'Home') && (
        <div className="cottage-zzz-container">
          <div className="sleepy-z z1">z</div>
          <div className="sleepy-z z2">z</div>
          <div className="sleepy-z z3">Z</div>
        </div>
      )}

      {/* EFFECT 6: Interactive Click Sparkle FX Burst */}
      {clickParticles.map((cp) => (
        <div
          key={cp.id}
          className={`interactive-click-particle particle-${cp.shape}`}
          style={{
            left: cp.x,
            top: cp.y,
            width: cp.size,
            height: cp.size,
            '--vx': `${cp.vx}px`,
            '--vy': `${cp.vy}px`,
            '--rot': `${cp.rotation}deg`,
          }}
        >
          {cp.shape === 'xp' && <span className="xp-orb" />}
          {cp.shape === 'heart' && '💖'}
          {cp.shape === 'star' && '✨'}
          {cp.shape === 'emerald' && '💎'}
          {cp.shape === 'sparkle' && '✦'}
        </div>
      ))}
    </div>
  );
};

export default React.memo(BackgroundEffects);
