import React, { useState, useEffect, useCallback } from 'react';
import './index.css';
import Sidebar from './components/Sidebar';
import BackgroundEffects from './components/BackgroundEffects';
import Home from './components/pages/Home';
import About from './components/pages/About';
import Skills from './components/pages/Skills';
import Projects from './components/pages/Projects';
import Certifications from './components/pages/Certifications';
import Contact from './components/pages/Contact';
import { soundFX } from './utils/audio';

// Exact image paths matching files in public/
const backgroundMap = {
  Home: '/home.png',
  About: '/About.png',
  Skills: '/skills.png',
  Projects: '/projects.png',
  Certifications: '/certification.png',
  Contact: '/conatct.png',
};

function App() {
  const [activePage, setActivePage] = useState('Home');
  const [cinematicMode, setCinematicMode] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1); // 1 = standard cinematic zoom, 1.25 = deep zoom
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });

  // Handle smooth mouse movement for parallax & interactive camera pan
  const handleMouseMove = useCallback((e) => {
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    setMousePos({ x, y });
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  const toggleCinematicMode = () => {
    soundFX.playPop();
    setCinematicMode((prev) => !prev);
  };

  const toggleZoom = (e) => {
    e.stopPropagation();
    soundFX.playPop();
    setZoomLevel((prev) => (prev === 1 ? 1.3 : 1));
  };

  const renderActivePage = () => {
    switch (activePage) {
      case 'Home':
        return <Home setActivePage={setActivePage} />;
      case 'About':
        return <About />;
      case 'Skills':
        return <Skills />;
      case 'Projects':
        return <Projects />;
      case 'Certifications':
        return <Certifications />;
      case 'Contact':
        return <Contact />;
      default:
        return <Home setActivePage={setActivePage} />;
    }
  };

  // Compute 3D parallax transformation for the active background image
  const parallaxX = (mousePos.x - 0.5) * -30;
  const parallaxY = (mousePos.y - 0.5) * -20;
  const rotateY = (mousePos.x - 0.5) * 4;
  const rotateX = (mousePos.y - 0.5) * -4;

  return (
    <div className={`app-viewport ${cinematicMode ? 'cinematic-view' : ''}`}>
      {/* Dynamic Background Image Layers with Cinematic Breathing Zoom & Mouse Parallax */}
      <div
        className="scene-viewport-canvas"
        style={{
          transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(${zoomLevel})`,
          transition: 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {Object.entries(backgroundMap).map(([pageKey, imgSrc]) => {
          const isCurrent = activePage === pageKey;
          return (
            <div
              key={pageKey}
              className={`bg-layer ${isCurrent ? 'active' : 'inactive'} bg-${pageKey.toLowerCase()}`}
              style={{
                backgroundImage: `url(${imgSrc})`,
                transform: `translate3d(${parallaxX}px, ${parallaxY}px, 0)`,
              }}
            >
              {/* Internal Image Shimmer / Vignette Overlay */}
              <div className="bg-image-shimmer" />
            </div>
          );
        })}
      </div>

      {/* 5-6 Atmospheric Animated Layers (Godrays, Petals, Mist, Biome Particles, Sunflare, Click FX) */}
      <BackgroundEffects activePage={activePage} mousePos={mousePos} />

      {/* Ambient Vignette & Scrim */}
      <div className="scrim-overlay" />

      {/* Cinematic Viewport Controls (Spyglass / Inspect & Zoom) */}
      <div className="cinematic-hud-controls">
        <button
          className={`hud-pill-btn ${cinematicMode ? 'active-hud' : ''}`}
          onClick={toggleCinematicMode}
          title={cinematicMode ? 'Exit Cinematic Mode (Show UI)' : 'Cinematic View (Hide UI & Admire Animated Scene)'}
        >
          <span style={{ fontSize: '16px' }}>{cinematicMode ? '✕' : '🔭'}</span>
          <span>{cinematicMode ? 'Exit Cinematic' : 'Cinematic Scene'}</span>
        </button>

        {cinematicMode && (
          <button
            className="hud-pill-btn zoom-pill"
            onClick={toggleZoom}
            title={zoomLevel > 1 ? 'Zoom Out (1x)' : 'Deep Zoom (1.3x)'}
          >
            <span style={{ fontSize: '15px' }}>{zoomLevel > 1 ? '🔍 1x' : '🔎 1.3x Zoom'}</span>
          </button>
        )}
      </div>

      {/* Authentic Frosted Glass Sidebar (hides in cinematic mode) */}
      {!cinematicMode && (
        <Sidebar activePage={activePage} setActivePage={setActivePage} />
      )}

      {/* Main Page Overlay (hides in cinematic mode) */}
      {!cinematicMode && (
        <main style={{ position: 'relative', width: '100%', height: '100%', zIndex: 30 }}>
          {renderActivePage()}
        </main>
      )}

      {/* Cinematic hint when in view mode */}
      {cinematicMode && (
        <div className="cinematic-hint-pill">
          <span>✨ Click anywhere to spawn magic particles • Move mouse to pan &amp; explore</span>
        </div>
      )}
    </div>
  );
}

export default App;
